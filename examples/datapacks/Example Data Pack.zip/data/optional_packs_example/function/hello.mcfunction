say Optional Packs example data pack loaded
